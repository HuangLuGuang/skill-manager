#!/usr/bin/env python3
"""
比亚迪新闻数据整理主脚本
整合搜索、处理、报告生成全流程
"""

import os
import sys
import json
import argparse
from datetime import datetime, timedelta
from pathlib import Path

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from process_news import BYDNewsProcessor
from generate_report import BYDReportGenerator


class BYDNewsCollector:
    """比亚迪新闻收集器"""
    
    def __init__(self, output_dir: str = "reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.processor = BYDNewsProcessor()
        self.report_generator = BYDReportGenerator()
        
        # 搜索关键词
        self.search_keywords = [
            "比亚迪", "BYD", "比亚迪股票", "比亚迪股份", 
            "比亚迪投资", "新能源汽车比亚迪", "比亚迪财报",
            "比亚迪销量", "比亚迪电池", "比亚迪技术",
            "比亚迪市场", "比亚迪海外", "比亚迪合作"
        ]
    
    def search_news(self, days: int = 1) -> list:
        """
        搜索比亚迪相关新闻
        注意：这里需要集成Tavily搜索API
        目前返回模拟数据供测试
        """
        print(f"搜索最近{days}天的比亚迪新闻...")
        
        # 模拟搜索数据
        today = datetime.now()
        sample_news = []
        
        # 生成一些示例新闻
        sample_templates = [
            {
                "title": "比亚迪发布{year}年第一季度财报，净利润同比增长{percent}%",
                "content": "比亚迪今日发布{year}年第一季度财报，显示公司净利润达到XX亿元，同比增长{percent}%，超出市场预期。新能源汽车销量持续增长，市场份额进一步扩大。",
                "source": "新浪财经",
                "url": "https://finance.sina.com.cn/stock/relnews/cn/{date}/doc-xxxxx.shtml"
            },
            {
                "title": "比亚迪新能源汽车{month}月销量再创新高",
                "content": "根据最新数据，比亚迪{month}月份新能源汽车销量达到XX万辆，同比增长{growth}%，市场份额进一步扩大。",
                "source": "东方财富",
                "url": "https://www.eastmoney.com/{date}/xxxxx"
            },
            {
                "title": "比亚迪与宁德时代达成战略合作",
                "content": "比亚迪宣布与宁德时代达成战略合作协议，双方将在电池技术研发和供应链方面深度合作。",
                "source": "证券时报",
                "url": "https://www.stcn.com/{date}/xxxxx"
            },
            {
                "title": "比亚迪获{country}市场大额订单",
                "content": "比亚迪近日获得{country}市场XX辆新能源汽车订单，标志着公司海外市场拓展取得新突破。",
                "source": "财联社",
                "url": "https://www.cls.cn/{date}/xxxxx"
            },
            {
                "title": "分析师看好比亚迪，上调目标价至{price}元",
                "content": "多家券商发布研报，看好比亚迪未来发展，将目标价上调至{price}元，维持买入评级。",
                "source": "华尔街见闻",
                "url": "https://wallstreetcn.com/{date}/xxxxx"
            }
        ]
        
        countries = ["美国", "欧洲", "日本", "澳大利亚", "东南亚"]
        
        for i in range(10):  # 生成10条示例新闻
            template = sample_templates[i % len(sample_templates)]
            date_str = today.strftime("%Y-%m-%d")
            
            # 动态填充模板
            title = template["title"].format(
                year=today.year,
                percent=25 + i*2,
                month=today.month,
                growth=30 + i*3,
                country=countries[i % len(countries)],
                price=280 + i*5
            )
            
            content = template["content"].format(
                year=today.year,
                percent=25 + i*2,
                month=today.month,
                growth=30 + i*3,
                country=countries[i % len(countries)],
                price=280 + i*5 if 'price' in template["content"] else ''
            )
            
            url = template["url"].format(date=date_str)
            
            # 模拟发布时间（最近N天内）
            hours_ago = i * 2  # 每条新闻间隔2小时
            publish_time = today - timedelta(hours=hours_ago)
            
            news_item = {
                "title": title,
                "content": content,
                "source": template["source"],
                "url": url,
                "published_date": publish_time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
                "search_keyword": self.search_keywords[i % len(self.search_keywords)]
            }
            
            sample_news.append(news_item)
        
        print(f"找到 {len(sample_news)} 条相关新闻")
        return sample_news
    
    def process_and_save(self, news_data: list, format: str = "all"):
        """处理新闻并保存报告"""
        print("处理新闻数据...")
        
        # 处理新闻
        processed_news = self.processor.process_news_items(news_data)
        
        # 生成报告
        print("生成报告...")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if format in ["markdown", "all"]:
            markdown_report = self.report_generator.generate_markdown_report(processed_news)
            md_file = self.output_dir / f"byd_news_report_{timestamp}.md"
            md_file.write_text(markdown_report, encoding="utf-8")
            print(f"Markdown报告已保存: {md_file}")
        
        if format in ["text", "all"]:
            text_report = self.report_generator.generate_text_report(processed_news)
            txt_file = self.output_dir / f"byd_news_summary_{timestamp}.txt"
            txt_file.write_text(text_report, encoding="utf-8")
            print(f"文本报告已保存: {txt_file}")
        
        if format in ["json", "all"]:
            json_report = self.report_generator.generate_json_report(processed_news)
            json_file = self.output_dir / f"byd_news_data_{timestamp}.json"
            json_file.write_text(json.dumps(json_report, indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"JSON数据已保存: {json_file}")
        
        # 保存原始数据
        raw_file = self.output_dir / f"byd_news_raw_{timestamp}.json"
        raw_file.write_text(json.dumps(news_data, indent=2, ensure_ascii=False), encoding="utf-8")
        
        # 生成今日摘要
        self._generate_daily_summary(processed_news, timestamp)
        
        return processed_news
    
    def _generate_daily_summary(self, processed_news: list, timestamp: str):
        """生成每日摘要"""
        stats = self.processor.generate_statistics(processed_news)
        key_news = self.processor.get_key_news(processed_news, max_items=3)
        
        summary = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "timestamp": timestamp,
            "total_news": stats["total_news"],
            "today_news": stats["today_news"],
            "sentiment": {
                "positive": stats["sentiment_distribution"]["正面"],
                "neutral": stats["sentiment_distribution"]["中性"],
                "negative": stats["sentiment_distribution"]["负面"]
            },
            "key_news_titles": [item["title"] for item in key_news],
            "main_categories": list(stats["category_distribution"].keys())[:3]
        }
        
        summary_file = self.output_dir / f"daily_summary_{timestamp}.json"
        summary_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
        
        # 更新最新摘要
        latest_file = self.output_dir / "latest_summary.json"
        latest_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    
    def run_daily_report(self):
        """运行每日报告生成"""
        print("=" * 60)
        print(f"比亚迪新闻日报生成 - {datetime.now().strftime('%Y年%m月%d日 %H:%M')}")
        print("=" * 60)
        
        # 搜索新闻（最近1天）
        news_data = self.search_news(days=1)
        
        if not news_data:
            print("未找到相关新闻")
            return None
        
        # 处理并保存报告
        processed = self.process_and_save(news_data, format="all")
        
        print("\n" + "=" * 60)
        print("报告生成完成！")
        print(f"处理新闻总数: {len(processed)}")
        
        # 显示简要统计
        stats = self.processor.generate_statistics(processed)
        print(f"今日新闻: {stats['today_news']}条")
        print(f"情感分布: 正面{stats['sentiment_distribution']['正面']}/中性{stats['sentiment_distribution']['中性']}/负面{stats['sentiment_distribution']['负面']}")
        
        return processed


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="比亚迪新闻数据整理工具")
    parser.add_argument("--days", type=int, default=1, help="搜索最近几天的新闻（默认：1）")
    parser.add_argument("--output", type=str, default="reports", help="输出目录（默认：reports）")
    parser.add_argument("--format", type=str, default="all", 
                       choices=["markdown", "text", "json", "all"], 
                       help="输出格式（默认：all）")
    parser.add_argument("--daily", action="store_true", help="运行每日报告模式")
    
    args = parser.parse_args()
    
    collector = BYDNewsCollector(output_dir=args.output)
    
    if args.daily:
        collector.run_daily_report()
    else:
        # 搜索新闻
        news_data = collector.search_news(days=args.days)
        
        if news_data:
            # 处理并保存
            collector.process_and_save(news_data, format=args.format)
        else:
            print("未找到相关新闻")


if __name__ == "__main__":
    main()