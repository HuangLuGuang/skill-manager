# 比亚迪股票新闻数据整理技能

这是一个专门用于整理比亚迪（BYD）股票相关新闻数据的OpenClaw技能。每天自动搜索比亚迪相关新闻，整理成结构化报告。

## 功能特点

- 🔍 **自动搜索**：使用Tavily搜索API获取比亚迪最新新闻
- 📊 **智能分类**：自动将新闻分类（财报、投资、产品、市场等）
- 📈 **情感分析**：分析新闻情感倾向（正面/中性/负面）
- 📋 **报告生成**：生成Markdown、文本、JSON格式报告
- ⏰ **定时执行**：支持每天自动运行

## 安装与配置

### 1. 安装技能
将技能目录复制到OpenClaw的skills目录：
```bash
cp -r byd-stock-news ~/.openclaw/workspace/skills/
```

### 2. 配置Tavily API
确保Tavily搜索技能已安装并配置API密钥：
```bash
# 安装Tavily技能（如果尚未安装）
openclaw skills install tavily-search
```

### 3. 测试技能
运行测试脚本：
```bash
cd ~/.openclaw/workspace/skills/byd-stock-news/scripts
python3 main.py --daily
```

## 使用方法

### 手动运行
```bash
# 生成今日报告
python3 scripts/main.py --daily

# 搜索最近3天新闻
python3 scripts/main.py --days 3

# 只生成Markdown报告
python3 scripts/main.py --format markdown
```

### 在OpenClaw中使用
当用户需要比亚迪新闻时，技能会自动触发：
- "帮我搜索今天比亚迪相关的投资消息"
- "整理比亚迪股票新闻"
- "生成比亚迪每日新闻报告"

### 定时任务设置
使用OpenClaw的cron功能设置每天自动执行：

```yaml
# 在OpenClaw配置中添加定时任务
schedule:
  kind: "cron"
  expr: "0 9 * * *"  # 每天上午9点执行
  tz: "Asia/Shanghai"
payload:
  kind: "agentTurn"
  message: "请运行比亚迪新闻日报生成任务"
```

## 报告输出

技能会生成以下文件：

### 1. 详细报告 (`byd_news_report_YYYYMMDD_HHMMSS.md`)
- 完整的Markdown格式报告
- 包含新闻分类、摘要、分析
- 适合阅读和分享

### 2. 简洁摘要 (`byd_news_summary_YYYYMMDD_HHMMSS.txt`)
- 文本格式简洁报告
- 关键新闻摘要
- 适合快速浏览

### 3. 结构化数据 (`byd_news_data_YYYYMMDD_HHMMSS.json`)
- JSON格式结构化数据
- 包含所有新闻条目和元数据
- 适合程序处理

### 4. 每日摘要 (`daily_summary_YYYYMMDD_HHMMSS.json`)
- 每日关键统计数据
- 情感分布
- 主要分类

## 文件结构

```
byd-stock-news/
├── SKILL.md                    # 技能主文件
├── README.md                   # 说明文档
├── scripts/
│   ├── main.py                 # 主执行脚本
│   ├── process_news.py         # 新闻处理脚本
│   └── generate_report.py      # 报告生成脚本
└── references/
    └── news_categories.md      # 新闻分类标准
```

## 新闻分类体系

技能使用以下分类标准：

1. **财报与业绩** - 财务报告、业绩数据
2. **投资与融资** - 融资、投资、并购
3. **产品与技术** - 新产品、技术研发
4. **市场与销售** - 销量、市场份额
5. **政策与行业** - 政策影响、行业动态
6. **股价与市场** - 股价变动、分析师评级
7. **其他新闻** - 其他相关新闻

## 自定义配置

### 修改搜索关键词
编辑 `scripts/main.py` 中的 `search_keywords` 列表：
```python
self.search_keywords = [
    "比亚迪", "BYD", "比亚迪股票", 
    # 添加更多关键词...
]
```

### 调整分类标准
编辑 `references/news_categories.md` 文件，修改分类关键词和优先级。

### 修改输出格式
编辑 `scripts/generate_report.py`，自定义报告模板和格式。

## 依赖项

- Python 3.8+
- OpenClaw Tavily搜索技能
- 网络连接（用于搜索新闻）

## 故障排除

### 1. 搜索不到新闻
- 检查网络连接
- 验证Tavily API密钥配置
- 调整搜索关键词

### 2. 分类不准确
- 更新 `news_categories.md` 中的关键词
- 调整分类优先级

### 3. 报告生成失败
- 检查Python依赖
- 验证文件写入权限
- 查看错误日志

## 更新日志

### v1.0 (2026-03-11)
- 初始版本发布
- 支持基本新闻搜索和处理
- 生成Markdown、文本、JSON格式报告
- 包含情感分析和分类功能

## 贡献

欢迎提交Issue和Pull Request来改进这个技能。

## 许可证

MIT License