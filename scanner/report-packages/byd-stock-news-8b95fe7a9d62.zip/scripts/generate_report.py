#!/usr/bin/env python3
"""
比亚迪新闻报告生成脚本
用于生成结构化新闻报告
"""

import json
from datetime import datetime
from typing import List, Dict, Any
from process_news import BYDNewsProcessor


class BYDReportGenerator:
    """比亚迪报告生成器"""
    
    def __init__(self):
        self.processor = BYDNewsProcessor()
        self.today = datetime.now().strftime("%Y年%m月%d日")
    
    def generate_markdown_report(self, processed_news: List[Dict[str, Any]]) -> str:
        """生成Markdown格式报告"""
        stats = self.processor.generate_statistics(processed_news)
        key_news = self.processor.get_key_news(processed_news)
        high_relevance_news = self.processor.filter_high_relevance(processed_news)
        
        report = f"""# 比亚迪股票新闻日报 - {self.today}

## 📊 今日要点

**新闻概览**：
- 今日新闻总数：{stats['total_news']} 条
- 今日新增新闻：{stats['today_news']} 条
- 高相关性新闻：{stats['relevance_distribution']['高']} 条

**情感分布**：
- 正面新闻：{stats['sentiment_distribution']['正面']} 条
- 中性新闻：{stats['sentiment_distribution']['中性']} 条  
- 负面新闻：{stats['sentiment_distribution']['负面']} 条

## 🔑 关键新闻摘要

"""
        
        # 关键新闻
        for i, item in enumerate(key_news, 1):
            report += f"{i}. **{item['title']}**\n"
            report += f"   - 来源：{item['source']} | 时间：{item['published_date']}\n"
            report += f"   - 摘要：{item['summary']}\n"
            report += f"   - 情感：{item['sentiment']} | 相关性：{item['relevance']}\n"
            report += f"   - [阅读原文]({item['url']})\n\n"
        
        report += "## 📈 新闻分类汇总\n\n"
        
        # 按分类组织新闻
        categorized_news = {}
        for item in high_relevance_news:
            category = item["category"]
            if category not in categorized_news:
                categorized_news[category] = []
            categorized_news[category].append(item)
        
        for category, items in categorized_news.items():
            report += f"### {category} ({len(items)}条)\n\n"
            
            for item in items:
                # 添加表情符号表示情感
                sentiment_emoji = {
                    "正面": "✅",
                    "中性": "➖", 
                    "负面": "⚠️"
                }.get(item["sentiment"], "➖")
                
                report += f"- {sentiment_emoji} **{item['title']}**\n"
                report += f"  - 来源：{item['source']} ({item['credibility']}可信度) | 时间：{item['published_date']}\n"
                report += f"  - 摘要：{item['summary']}\n"
                report += f"  - [原文链接]({item['url']})\n\n"
        
        report += "## 📊 详细数据统计\n\n"
        
        # 分类分布
        report += "### 新闻分类分布\n"
        for category, count in stats["category_distribution"].items():
            percentage = (count / stats["total_news"] * 100) if stats["total_news"] > 0 else 0
            report += f"- {category}: {count}条 ({percentage:.1f}%)\n"
        
        report += "\n### 来源分布（前5）\n"
        for source_info in stats["top_sources"]:
            report += f"- {source_info['source']}: {source_info['count']}条\n"
        
        report += "\n### 相关性分布\n"
        for relevance, count in stats["relevance_distribution"].items():
            percentage = (count / stats["total_news"] * 100) if stats["total_news"] > 0 else 0
            report += f"- {relevance}相关性: {count}条 ({percentage:.1f}%)\n"
        
        report += "\n## 💡 投资建议摘要\n\n"
        
        # 基于新闻情感生成建议
        positive_ratio = stats["sentiment_distribution"]["正面"] / stats["total_news"] if stats["total_news"] > 0 else 0
        negative_ratio = stats["sentiment_distribution"]["负面"] / stats["total_news"] if stats["total_news"] > 0 else 0
        
        report += "### 市场情绪分析\n"
        
        if positive_ratio > 0.6:
            report += "- **整体情绪积极**：多数新闻呈现正面基调\n"
            report += "- **短期展望**：市场信心较强，可能对股价形成支撑\n"
        elif negative_ratio > 0.6:
            report += "- **整体情绪谨慎**：负面新闻占主导\n"
            report += "- **短期展望**：需关注风险因素，股价可能承压\n"
        else:
            report += "- **整体情绪中性**：正负面新闻相对平衡\n"
            report += "- **短期展望**：市场观望情绪较浓，等待更多催化剂\n"
        
        report += "\n### 关注重点\n"
        
        # 根据关键新闻生成关注点
        if key_news:
            report += "基于今日关键新闻，建议关注：\n"
            for item in key_news[:3]:  # 取前3条关键新闻
                category = item["category"]
                if category == "财报与业绩":
                    report += f"- **财务表现**：关注{item['title'].split('，')[0] if '，' in item['title'] else item['title'][:20]}...\n"
                elif category == "产品与技术":
                    report += f"- **产品动态**：{item['title'].split('，')[0] if '，' in item['title'] else item['title'][:20]}...\n"
                elif category == "投资与融资":
                    report += f"- **资本动向**：{item['title'].split('，')[0] if '，' in item['title'] else item['title'][:20]}...\n"
        
        report += "\n### 风险提示\n"
        report += "1. 新闻数据仅供参考，不构成投资建议\n"
        report += "2. 股市有风险，投资需谨慎\n"
        report += "3. 请结合公司基本面和技术面综合分析\n"
        
        report += "\n## 🔍 明日关注\n\n"
        
        # 根据今日新闻推测明日关注点
        if "财报与业绩" in categorized_news:
            report += "- 关注财报详细数据的市场解读\n"
        if "产品与技术" in categorized_news:
            report += "- 跟踪新产品发布后的市场反馈\n"
        if "投资与融资" in categorized_news:
            report += "- 监测资本运作的后续进展\n"
        
        report += "- 关注新能源汽车行业政策动向\n"
        report += "- 监控比亚迪股价关键技术位\n"
        
        report += "\n---\n"
        report += f"*报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n"
        report += "*数据来源：Tavily搜索 + 公开新闻整理*\n"
        report += "*免责声明：本报告仅供参考，不构成任何投资建议*\n"
        
        return report
    
    def generate_text_report(self, processed_news: List[Dict[str, Any]]) -> str:
        """生成简洁文本格式报告"""
        stats = self.processor.generate_statistics(processed_news)
        key_news = self.processor.get_key_news(processed_news, max_items=3)
        
        report = f"比亚迪新闻简报 {self.today}\n"
        report += "=" * 50 + "\n\n"
        
        report += f"📈 今日统计：{stats['today_news']}条新新闻，{stats['total_news']}条总新闻\n"
        report += f"😊 情感分布：正面{stats['sentiment_distribution']['正面']} | 中性{stats['sentiment_distribution']['中性']} | 负面{stats['sentiment_distribution']['负面']}\n"
        report += f"🎯 高相关性：{stats['relevance_distribution']['高']}条\n\n"
        
        report += "🔑 关键新闻：\n"
        for i, item in enumerate(key_news, 1):
            report += f"{i}. {item['title'][:50]}...\n"
            report += f"   来源：{item['source']} | 时间：{item['published_date'][:10]}\n"
            report += f"   情感：{item['sentiment']} | 链接：{item['url'][:50]}...\n\n"
        
        report += "📊 分类TOP3：\n"
        sorted_categories = sorted(stats["category_distribution"].items(), key=lambda x: x[1], reverse=True)
        for category, count in sorted_categories[:3]:
            report += f"- {category}: {count}条\n"
        
        report += "\n💡 简要分析：\n"
        positive_ratio = stats["sentiment_distribution"]["正面"] / stats["total_news"] if stats["total_news"] > 0 else 0
        if positive_ratio > 0.5:
            report += "今日新闻整体偏正面，市场情绪积极。\n"
        elif positive_ratio < 0.3:
            report += "今日新闻偏中性或负面，建议谨慎关注。\n"
        else:
            report += "今日新闻情绪平衡，市场观望中。\n"
        
        return report
    
    def generate_json_report(self, processed_news: List[Dict[str, Any]]) -> Dict[str, Any]:
        """生成JSON格式报告（用于程序处理）"""
        stats = self.processor.generate_statistics(processed_news)
        key_news = self.processor.get_key_news(processed_news)
        
        return {
            "report_date": self.today,
            "generated_at": datetime.now().isoformat(),
            "statistics": stats,
            "key_news": key_news,
            "all_news_count": len(processed_news),
            "high_relevance_news": self.processor.filter_high_relevance(processed_news),
            "summary": {
                "overall_sentiment": self._calculate_overall_sentiment(stats),
                "main_themes": self._extract_main_themes(processed_news),
                "investment_implications": self._generate_implications(processed_news)
            }
        }
    
    def _calculate_overall_sentiment(self, stats: Dict[str, Any]) -> str:
        """计算整体情感倾向"""
        positive = stats["sentiment_distribution"]["正面"]
        negative = stats["sentiment_distribution"]["负面"]
        total = stats["total_news"]
        
        if total == 0:
            return "neutral"
        
        positive_ratio = positive / total
        negative_ratio = negative / total
        
        if positive_ratio > 0.6:
            return "positive"
        elif negative_ratio > 0.6:
            return "negative"
        elif positive_ratio > negative_ratio:
            return "slightly_positive"
        elif negative_ratio > positive_ratio:
            return "slightly_negative"
        else:
            return "neutral"
    
    def _extract_main_themes(self, processed_news: List[Dict[str, Any]]) -> List[str]:
        """提取主要主题"""
        themes = []
        category_count = {}
        
        for item in processed_news:
            category = item["category"]
            category_count[category] = category_count.get(category, 0) + 1
        
        # 取数量最多的3个分类
        sorted_categories = sorted(category_count.items(), key=lambda x: x[1], reverse=True)
        for category, count in sorted_categories[:3]:
            themes.append(f"{category}({count}条)")
        
        return themes
    
    def _generate_implications(self, processed_news: List[Dict[str, Any]]) -> List[str]:
        """生成投资影响分析"""
        implications = []
        
        # 检查是否有重大新闻
        high_impact_keywords = ["财报", "业绩", "投资", "融资", "收购", "合作"]
        for item in processed_news:
            if item["relevance"] == "高":
                title = item["title"]
                for keyword in high_impact_keywords:
                    if keyword in title:
                        implications.append(f"关注{keyword}相关新闻：{title[:30]}...")
                        break
        
        if not implications:
            implications.append("今日无重大影响新闻，市场平稳运行")
        
        return implications


def main():
    """主函数 - 测试用"""
    # 示例数据
    sample_news = [
        {
            "title": "比亚迪发布2026年第一季度财报，净利润同比增长30%",
            "content": "比亚迪今日发布2026年第一季度财报，显示公司净利润达到XX亿元，同比增长30%，超出市场预期。新能源汽车销量持续增长，市场份额进一步扩大。",
            "source": "新浪财经",
            "url": "https://finance.sina.com.cn/stock/relnews/cn/2026-03-11/doc-xxxxx.shtml",
            "published_date": "2026-03-11T10:30:00+08:00"
        },
        {
            "title": "比亚迪新能源汽车销量再创新高",
            "content": "根据最新数据，比亚迪3月份新能源汽车销量达到XX万辆，同比增长40%，市场份额进一步扩大。",
            "source": "东方财富",
            "url": "https://www.eastmoney.com/xxxxx",
            "published_date": "2026-03-11T09:15:00+08:00"
        },
        {
            "title": "比亚迪与宁德时代达成战略合作",
            "content": "比亚迪宣布与宁德时代达成战略合作协议，双方将在电池技术研发和供应链方面深度合作。",
            "source": "证券时报",
            "url": "https://www.stcn.com/xxxxx",
            "published_date": "2026-03-10T14:20:00+08:00"
        }
    ]
    
    processor = BYDNewsProcessor()
    processed = processor.process_news_items(sample_news)
    
    generator = BYDReportGenerator()
    
    print("Markdown报告:")
    print(generator.generate_markdown_report(processed))
    
    print("\n" + "="*50 + "\n")
    
    print("文本报告:")
    print(generator.generate_text_report(processed))
    
    print("\n" + "="*50 + "\n")
    
    print("JSON报告:")
    print(json.dumps(generator.generate_json_report(processed), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()