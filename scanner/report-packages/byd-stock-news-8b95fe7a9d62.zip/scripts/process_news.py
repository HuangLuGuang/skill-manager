#!/usr/bin/env python3
"""
比亚迪新闻处理脚本
用于处理从Tavily搜索获取的比亚迪相关新闻数据
"""

import json
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional


class BYDNewsProcessor:
    """比亚迪新闻处理器"""
    
    def __init__(self):
        # 关键词分类
        self.category_keywords = {
            "财报与业绩": ["财报", "业绩", "营收", "利润", "季度报告", "年报", "财务", "盈利", "亏损"],
            "投资与融资": ["投资", "融资", "募资", "增发", "债券", "基金", "股东", "股权", "收购", "并购"],
            "产品与技术": ["新车", "车型", "技术", "研发", "电池", "电动", "新能源", "自动驾驶", "智能"],
            "市场与销售": ["销量", "销售", "市场", "份额", "出口", "海外", "订单", "交付", "客户"],
            "政策与行业": ["政策", "补贴", "法规", "标准", "行业", "竞争", "合作", "伙伴", "联盟"],
            "股价与市场": ["股价", "股票", "市值", "涨跌", "交易", "分析师", "评级", "目标价"]
        }
        
        # 来源可信度评级
        self.source_credibility = {
            "高": ["新浪财经", "东方财富", "证券时报", "上海证券报", "中国证券报", "财联社", "华尔街见闻"],
            "中": ["腾讯财经", "网易财经", "搜狐财经", "凤凰财经", "金融界", "雪球"],
            "低": ["自媒体", "博客", "论坛", "未知来源"]
        }
    
    def categorize_news(self, title: str, content: str) -> str:
        """根据标题和内容分类新闻"""
        text = f"{title} {content}".lower()
        
        # 检查每个分类的关键词
        for category, keywords in self.category_keywords.items():
            for keyword in keywords:
                if keyword.lower() in text:
                    return category
        
        # 默认分类
        return "其他新闻"
    
    def assess_relevance(self, title: str, content: str) -> str:
        """评估新闻与比亚迪的相关性"""
        text = f"{title} {content}".lower()
        
        # 核心关键词
        core_keywords = ["比亚迪", "byd", "002594", "01211"]
        # 相关关键词
        related_keywords = ["新能源", "电动车", "电动汽车", "电池", "王传福"]
        
        core_count = sum(1 for kw in core_keywords if kw.lower() in text)
        related_count = sum(1 for kw in related_keywords if kw.lower() in text)
        
        if core_count >= 2:
            return "高"
        elif core_count >= 1 or related_count >= 2:
            return "中"
        else:
            return "低"
    
    def assess_sentiment(self, title: str, content: str) -> str:
        """评估新闻情感倾向"""
        text = f"{title} {content}"
        
        # 正面关键词
        positive_keywords = ["增长", "上涨", "利好", "突破", "创新", "领先", "优秀", "强劲", "超预期", "看好", "推荐", "买入"]
        # 负面关键词
        negative_keywords = ["下跌", "下滑", "利空", "亏损", "问题", "风险", "警告", "担忧", "看空", "卖出", "减持"]
        
        pos_count = sum(1 for kw in positive_keywords if kw in text)
        neg_count = sum(1 for kw in negative_keywords if kw in text)
        
        if pos_count > neg_count:
            return "正面"
        elif neg_count > pos_count:
            return "负面"
        else:
            return "中性"
    
    def assess_source_credibility(self, source: str) -> str:
        """评估新闻来源可信度"""
        for credibility, sources in self.source_credibility.items():
            for s in sources:
                if s in source:
                    return credibility
        return "低"
    
    def extract_date(self, date_str: str) -> Optional[datetime]:
        """提取日期信息"""
        try:
            # 尝试多种日期格式
            formats = [
                "%Y-%m-%dT%H:%M:%S%z",
                "%Y-%m-%d %H:%M:%S",
                "%Y年%m月%d日",
                "%Y/%m/%d",
                "%Y-%m-%d"
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(date_str, fmt)
                except:
                    continue
            
            # 如果无法解析，返回None
            return None
        except:
            return None
    
    def process_news_items(self, news_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """处理新闻条目列表"""
        processed_news = []
        
        for item in news_items:
            try:
                # 提取基本信息
                title = item.get("title", "")
                content = item.get("content", "")
                source = item.get("source", "未知来源")
                url = item.get("url", "")
                published_date = item.get("published_date", "")
                
                # 处理和分析
                category = self.categorize_news(title, content)
                relevance = self.assess_relevance(title, content)
                sentiment = self.assess_sentiment(title, content)
                credibility = self.assess_source_credibility(source)
                
                # 提取日期
                date_obj = self.extract_date(published_date)
                if date_obj:
                    formatted_date = date_obj.strftime("%Y-%m-%d %H:%M")
                    is_today = date_obj.date() == datetime.now().date()
                else:
                    formatted_date = published_date
                    is_today = False
                
                # 生成摘要（前100字符）
                summary = content[:100] + "..." if len(content) > 100 else content
                
                # 构建处理后的新闻条目
                processed_item = {
                    "title": title,
                    "summary": summary,
                    "source": source,
                    "url": url,
                    "published_date": formatted_date,
                    "is_today": is_today,
                    "category": category,
                    "relevance": relevance,
                    "sentiment": sentiment,
                    "credibility": credibility,
                    "raw_content": content[:500]  # 保留部分原始内容供参考
                }
                
                processed_news.append(processed_item)
                
            except Exception as e:
                print(f"处理新闻时出错: {e}")
                continue
        
        # 按相关性、日期排序
        processed_news.sort(
            key=lambda x: (
                0 if x["relevance"] == "高" else 1 if x["relevance"] == "中" else 2,
                1 if x["is_today"] else 0,
                x["published_date"] if isinstance(x["published_date"], str) else ""
            ),
            reverse=True
        )
        
        return processed_news
    
    def generate_statistics(self, processed_news: List[Dict[str, Any]]) -> Dict[str, Any]:
        """生成统计数据"""
        total = len(processed_news)
        
        # 按分类统计
        category_stats = {}
        for item in processed_news:
            category = item["category"]
            category_stats[category] = category_stats.get(category, 0) + 1
        
        # 按情感统计
        sentiment_stats = {"正面": 0, "中性": 0, "负面": 0}
        for item in processed_news:
            sentiment = item["sentiment"]
            if sentiment in sentiment_stats:
                sentiment_stats[sentiment] += 1
        
        # 按相关性统计
        relevance_stats = {"高": 0, "中": 0, "低": 0}
        for item in processed_news:
            relevance = item["relevance"]
            if relevance in relevance_stats:
                relevance_stats[relevance] += 1
        
        # 今日新闻数量
        today_news = sum(1 for item in processed_news if item.get("is_today", False))
        
        return {
            "total_news": total,
            "today_news": today_news,
            "category_distribution": category_stats,
            "sentiment_distribution": sentiment_stats,
            "relevance_distribution": relevance_stats,
            "top_sources": self._get_top_sources(processed_news)
        }
    
    def _get_top_sources(self, processed_news: List[Dict[str, Any]], top_n: int = 5) -> List[Dict[str, Any]]:
        """获取主要新闻来源"""
        source_count = {}
        for item in processed_news:
            source = item["source"]
            source_count[source] = source_count.get(source, 0) + 1
        
        # 按数量排序
        sorted_sources = sorted(source_count.items(), key=lambda x: x[1], reverse=True)
        
        return [{"source": source, "count": count} for source, count in sorted_sources[:top_n]]
    
    def filter_high_relevance(self, processed_news: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """筛选高相关性新闻"""
        return [item for item in processed_news if item["relevance"] == "高"]
    
    def get_key_news(self, processed_news: List[Dict[str, Any]], max_items: int = 5) -> List[Dict[str, Any]]:
        """获取关键新闻（高相关性+今日）"""
        key_news = []
        for item in processed_news:
            if item["relevance"] == "高" and item["is_today"]:
                key_news.append(item)
                if len(key_news) >= max_items:
                    break
        
        # 如果不够，补充其他高相关性新闻
        if len(key_news) < max_items:
            for item in processed_news:
                if item["relevance"] == "高" and item not in key_news:
                    key_news.append(item)
                    if len(key_news) >= max_items:
                        break
        
        return key_news


def main():
    """主函数 - 测试用"""
    # 示例数据
    sample_news = [
        {
            "title": "比亚迪发布2026年第一季度财报，净利润同比增长30%",
            "content": "比亚迪今日发布2026年第一季度财报，显示公司净利润达到XX亿元，同比增长30%，超出市场预期。",
            "source": "新浪财经",
            "url": "https://finance.sina.com.cn/stock/relnews/cn/2026-03-11/doc-xxxxx.shtml",
            "published_date": "2026-03-11T10:30:00+08:00"
        },
        {
            "title": "比亚迪新能源汽车销量再创新高",
            "content": "根据最新数据，比亚迪3月份新能源汽车销量达到XX万辆，同比增长40%，市场份额进一步扩大。",
            "source": "东方财富",
            "url": "https://www.eastmoney.com/xxxxx",
            "published_date": "2026-03-11T09:15:00+08:00"
        }
    ]
    
    processor = BYDNewsProcessor()
    processed = processor.process_news_items(sample_news)
    stats = processor.generate_statistics(processed)
    
    print("处理后的新闻:")
    for item in processed:
        print(f"- {item['title']} ({item['category']}, {item['relevance']}, {item['sentiment']})")
    
    print("\n统计数据:")
    print(json.dumps(stats, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()